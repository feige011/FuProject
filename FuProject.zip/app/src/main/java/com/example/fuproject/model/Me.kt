package com.example.fuproject.model
object Me {
    lateinit var account:String
    lateinit var name:String
}