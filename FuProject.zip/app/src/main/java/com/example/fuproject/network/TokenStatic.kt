package com.example.fuproject.network

class TokenStatic {
    companion object{
        var TOKEN=""
    }
}